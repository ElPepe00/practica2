AUTORES:
	Antoni Jaume Lemesev
	Josep Oliver Vallespir
	Gabriel Riutort Álvarez

Como observaciones, puede haber ciertos errores o modificaciones de algunos niveles a otros.
Es decir, no hemos cambiado retroactivamente todos los niveles, de manera que puede haber pequeños fallos en un nivel que quedan corregidos en el posterior o posteriores. En este sentido, la referencia de funcionamiento son el nivel6.c y el my_shell.c, que son los que tienen implementaod todo en principio creemos que de forma correcta.